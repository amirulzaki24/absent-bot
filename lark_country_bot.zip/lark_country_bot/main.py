import lark_oapi as lark
from lark_oapi.api.im.v1 import *
import json

# Country code to transfer group mapping
transfer_map = {
    "DZ": "RoW Arabic - Account Security",
    "BH": "RoW Arabic - Account Security",
    "KM": "Backup EMEA (non-EU) - Account Security",
    "DJ": "Backup SEA - Account Security",
    "EG": "RoW Arabic - Account Security",
    "IQ": "RoW Arabic - Account Security",
    "JO": "RoW Arabic - Account Security",
    "KW": "RoW Arabic - Account Security",
    "LB": "RoW Arabic - Account Security",
    "LY": "RoW Arabic - Account Security",
    "MR": "RoW Arabic - Account Security",
    "MA": "RoW Arabic - Account Security",
    "OM": "RoW Arabic - Account Security",
    "PS": "RoW Arabic - Account Security",
    "QA": "RoW Arabic - Account Security",
    "SA": "RoW Arabic - Account Security",
    "SO": "RoW Arabic - Account Security",
    "SD": "RoW Arabic - Account Security",
    "SY": "RoW Arabic - Account Security",
    "TN": "RoW Arabic - Account Security",
    "AE": "RoW Arabic - Account Security",
    "YE": "RoW Arabic - Account Security",
    "BD": "RoW Bengali - Account Security",
    "CZ": "GCP Czech - Account Security",
    "NL": "GCP Dutch - Account Security",
    "GB": "GCP English - Account Security",
    "IE": "GCP English - Account Security",
    "PH": "RoW Filipino - Account Security",
    "FR": "GCP French - Account Security",
    "DE": "GCP German - Account Security",
    "ID": "RoW Indonesian - Account Security",
    "IT": "GCP Italian - Account Security",
    "JP": "RoW Japanese - Account Security",
    "KR": "RoW Korean - Account Security",
    "MY": "RoW Malay - Account Security",
    "CN": "RoW Mandarin Chinese - Account Security / Backup SEA - Account Security",
    "NP": "RoW Nepali - Account Security",
    "NO": "GCP Norwegian - Account Security",
    "PL": "GCP Polish - Account Security",
    "PT": "GCP Portugese - Account Security",
    "RO": "GCP Romanian - Account Security",
    "RU": "RoW Russian - Account Security",
    "ES": "GCP Spanish - Account Security",
    "SE": "GCP Swedish - Account Security",
    "TH": "RoW Thai - Account Security",
    "AU": "RoW AU/NZ - Account Security",
    "NZ": "RoW AU/NZ - Account Security",
    "IL": "RoW Israel - Account Security",
    "TR": "RoW Turkish - Account Security",
    "UA": "RoW Ukrainian - Account Security",
    "PK": "RoW Urdu - Account Security",
    "VN": "RoW Vietnamese - Account Security",
    "BR": "RoW Portugese - Account Security",
    "AR": "RoW Spanish - Account Security",
    "BB": "RoW Spanish - Account Security",
    "BM": "RoW Spanish - Account Security",
    "BO": "RoW Spanish - Account Security",
    "BS": "RoW Spanish - Account Security",
    "BZ": "RoW Spanish - Account Security",
    "CL": "RoW Spanish - Account Security",
    "CO": "RoW Spanish - Account Security",
    "CR": "RoW Spanish - Account Security",
    "DM": "RoW Spanish - Account Security",
    "DO": "RoW Spanish - Account Security",
    "EC": "RoW Spanish - Account Security",
    "GD": "RoW Spanish - Account Security",
    "GT": "RoW Spanish - Account Security",
    "GY": "RoW Spanish - Account Security",
    "HN": "RoW Spanish - Account Security",
    "HT": "RoW Spanish - Account Security",
    "JM": "RoW Spanish - Account Security",
    "KY": "RoW Spanish - Account Security",
    "MS": "RoW Spanish - Account Security",
    "MX": "RoW Spanish - Account Security",
    "NI": "RoW Spanish - Account Security",
    "PA": "RoW Spanish - Account Security",
    "PE": "RoW Spanish - Account Security",
    "PR": "RoW Spanish - Account Security",
    "PY": "RoW Spanish - Account Security",
    "SR": "RoW Spanish - Account Security",
    "SV": "RoW Spanish - Account Security",
    "TC": "Backup Latam Other/English - Account Security",
    "TT": "RoW Spanish - Account Security",
    "UY": "RoW Spanish - Account Security",
    "VE": "RoW Spanish - Account Security",
    "CA": "Canada English - Account Security",
    "AI": "Backup Latam Other/English - Account Security",
    "AG": "Backup Latam Other/English - Account Security",
    "AW": "Backup Latam Other/English - Account Security",
    "KN": "Backup Latam Other/English - Account Security",
    "LC": "Backup Latam Other/English - Account Security",
    "VC": "Backup Latam Other/English - Account Security",
    "VG": "Backup Latam Other/English - Account Security",
    "VI": "Backup Latam Other/English - Account Security",
    "HK": "Backup SEA - Account Security",
    "SG": "Backup SEA - Account Security",
    "TW": "Backup SEA - Account Security",
    "KZ": "Backup SEA - Account Security",
    "GH": "Backup SEA - Account Security",
    "GM": "Backup SEA - Account Security",
    "KE": "Backup SEA - Account Security",
    "LR": "Backup SEA - Account Security",
    "LS": "Backup SEA - Account Security",
    "MU": "Backup SEA - Account Security",
    "MW": "Backup SEA - Account Security",
    "NA": "Backup SEA - Account Security",
    "NG": "Backup SEA - Account Security",
    "SL": "Backup SEA - Account Security",
    "SS": "Backup SEA - Account Security",
    "UG": "Backup SEA - Account Security",
    "ZA": "Backup SEA - Account Security",
    "ZM": "Backup SEA - Account Security",
    "ZW": "Backup SEA - Account Security",
    "CY": "Backup EU Other - Account Security",
    "DK": "Backup EU Other - Account Security",
    "EE": "Backup EU Other - Account Security",
    "FI": "Backup EU Other - Account Security",
    "GF": "Backup EU Other - Account Security",
    "GP": "Backup EU Other - Account Security",
    "GR": "Backup EU Other - Account Security",
    "HR": "Backup EU Other - Account Security",
    "HU": "Backup EU Other - Account Security",
    "IS": "Backup EU Other - Account Security",
    "LI": "Backup EU Other - Account Security",
    "LT": "Backup EU Other - Account Security",
    "LU": "Backup EU Other - Account Security",
    "LV": "Backup EU Other - Account Security",
    "MF": "Backup EU Other - Account Security",
    "MQ": "Backup EU Other - Account Security",
    "TM": "Backup EU Other - Account Security",
    "RE": "Backup EU Other - Account Security",
    "SI": "Backup EU Other - Account Security",
    "SK": "Backup EU Other - Account Security",
    "SZ": "Backup EU Other - Account Security",
    "TY": "Backup EU Other - Account Security",
    "AD": "Backup EMEA (non-EU) - Account Security",
    "AF": "Backup EMEA (non-EU) - Account Security",
    "AL": "Backup EMEA (non-EU) - Account Security",
    "AM": "Backup EMEA (non-EU) - Account Security",
    "AX": "Backup EMEA (non-EU) - Account Security",
    "AZ": "Backup EMEA (non-EU) - Account Security",
    "BA": "Backup EMEA (non-EU) - Account Security",
    "BL": "Backup EMEA (non-EU) - Account Security",
    "BV": "Backup EMEA (non-EU) - Account Security",
    "CD": "Backup EMEA (non-EU) - Account Security",
    "CK": "Backup EMEA (non-EU) - Account Security",
    "CW": "Backup EMEA (non-EU) - Account Security",
    "EH": "Backup EMEA (non-EU) - Account Security",
    "FO": "Backup EMEA (non-EU) - Account Security",
    "GE": "Backup EMEA (non-EU) - Account Security",
    "GG": "Backup EMEA (non-EU) - Account Security",
    "GI": "Backup EMEA (non-EU) - Account Security",
    "GL": "Backup EMEA (non-EU) - Account Security",
    "IM": "Backup EMEA (non-EU) - Account Security",
    "JE": "Backup EMEA (non-EU) - Account Security",
    "MC": "Backup EMEA (non-EU) - Account Security",
    "MD": "Backup EMEA (non-EU) - Account Security",
    "ME": "Backup EMEA (non-EU) - Account Security",
    "MK": "Backup EMEA (non-EU) - Account Security",
    "NC": "Backup EMEA (non-EU) - Account Security",
    "PF": "Backup EMEA (non-EU) - Account Security",
    "PM": "Backup EMEA (non-EU) - Account Security",
    "RS": "Backup EMEA (non-EU) - Account Security",
    "SM": "Backup EMEA (non-EU) - Account Security",
    "SX": "Backup EMEA (non-EU) - Account Security",
    "TJ": "Backup EMEA (non-EU) - Account Security",
    "UZ": "Backup EMEA (non-EU) - Account Security",
    "WF": "Backup EMEA (non-EU) - Account Security",
    "XK": "Backup EMEA (non-EU) - Account Security",
    "AO": "Backup EMEA (non-EU) - Account Security",
    "BF": "Backup EMEA (non-EU) - Account Security",
    "BI": "Backup EMEA (non-EU) - Account Security",
    "BJ": "Backup EMEA (non-EU) - Account Security",
    "CF": "Backup EMEA (non-EU) - Account Security",
    "CG": "Backup EMEA (non-EU) - Account Security",
    "CI": "Backup EMEA (non-EU) - Account Security",
    "CM": "Backup EMEA (non-EU) - Account Security",
    "CV": "Backup EMEA (non-EU) - Account Security",
    "ER": "Backup EMEA (non-EU) - Account Security",
    "ET": "Backup EMEA (non-EU) - Account Security",
    "GA": "Backup EMEA (non-EU) - Account Security",
    "GN": "Backup EMEA (non-EU) - Account Security",
    "GQ": "Backup EMEA (non-EU) - Account Security",
    "GW": "Backup EMEA (non-EU) - Account Security",
    "MG": "Backup EMEA (non-EU) - Account Security",
    "ML": "Backup EMEA (non-EU) - Account Security",
    "MZ": "Backup EMEA (non-EU) - Account Security",
    "NE": "Backup EMEA (non-EU) - Account Security",
    "RW": "Backup EMEA (non-EU) - Account Security",
    "SC": "Backup EMEA (non-EU) - Account Security",
    "SN": "Backup EMEA (non-EU) - Account Security",
    "ST": "Backup EMEA (non-EU) - Account Security",
    "TD": "Backup EMEA (non-EU) - Account Security",
    "TG": "Backup EMEA (non-EU) - Account Security",
    "TZ": "Backup EMEA (non-EU) - Account Security",
    "BN": "Backup APAC - Account Security",
    "BT": "Backup APAC - Account Security",
    "CX": "Backup APAC - Account Security",
    "FJ": "Backup APAC - Account Security",
    "FM": "Backup APAC - Account Security",
    "IN": "Backup APAC - Account Security",
    "KH": "Backup APAC - Account Security",
    "KI": "Backup APAC - Account Security",
    "LA": "Backup APAC - Account Security",
    "LK": "Backup APAC - Account Security",
    "MH": "Backup APAC - Account Security",
    "MM": "Backup APAC - Account Security",
    "MN": "Backup APAC - Account Security",
    "MO": "Backup APAC - Account Security",
    "MP": "Backup APAC - Account Security",
    "MV": "Backup APAC - Account Security",
    "NR": "Backup APAC - Account Security",
    "NU": "Backup APAC - Account Security",
    "PG": "Backup APAC - Account Security",
    "PW": "Backup APAC - Account Security",
    "SB": "Backup APAC - Account Security",
    "TK": "Backup APAC - Account Security",
    "TL": "Backup APAC - Account Security",
    "TO": "Backup APAC - Account Security",
    "TV": "Backup APAC - Account Security",
    "VU": "Backup APAC - Account Security",
    "WS": "Backup APAC - Account Security",
}

def do_p2_im_message_receive_v1(data: P2ImMessageReceiveV1) -> None:
    res_content = ""
    if data.event.message.message_type == "text":
        # Extract the text user sent
        text = json.loads(data.event.message.content).get("text", "").strip().upper()
        # Check if country code is in mapping
        if text in transfer_map:
            res_content = transfer_map[text]
        else:
            res_content = "Country not found. Please provide a valid country code or reach out to muhammad.amirul@bytedance for support."

    content = json.dumps({"text": res_content})

    if data.event.message.chat_type == "p2p":
        request = (
            CreateMessageRequest.builder()
            .receive_id_type("chat_id")
            .request_body(
                CreateMessageRequestBody.builder()
                .receive_id(data.event.message.chat_id)
                .msg_type("text")
                .content(content)
                .build()
            )
            .build()
        )
        response = client.im.v1.chat.create(request)

        if not response.success():
            raise Exception(
                f"client.im.v1.chat.create failed, code: {response.code}, msg: {response.msg}, log_id: {response.get_log_id()}"
            )
    else:
        request: ReplyMessageRequest = (
            ReplyMessageRequest.builder()
            .message_id(data.event.message.message_id)
            .request_body(
                ReplyMessageRequestBody.builder()
                .content(content)
                .msg_type("text")
                .build()
            )
            .build()
        )
        response: ReplyMessageResponse = client.im.v1.message.reply(request)
        if not response.success():
            raise Exception(
                f"client.im.v1.message.reply failed, code: {response.code}, msg: {response.msg}, log_id: {response.get_log_id()}"
            )


# Register event handler
event_handler = (
    lark.EventDispatcherHandler.builder("", "")
    .register_p2_im_message_receive_v1(do_p2_im_message_receive_v1)
    .build()
)

# Create clients
client = lark.Client.builder().app_id(lark.APP_ID).app_secret(lark.APP_SECRET).build()
wsClient = lark.ws.Client(
    lark.APP_ID,
    lark.APP_SECRET,
    event_handler=event_handler,
    log_level=lark.LogLevel.DEBUG,
)


def main():
    wsClient.start()


if __name__ == "__main__":
    main()
